<?php
session_start();
require '_conf.php';
include 'includes/header.php';


$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);

$helper->deleteQcmsById($id);

$idQuery = 'DELETE FROM QCM WHERE ID_QCM = :id';
$idQuerySelect = 'SELECT * FROM QCM WHERE ID_QCM = :id';

$statementId = $pdo->prepare($idQuery);
$statementIdSelect = $pdo->prepare($idQuerySelect); 

$statementId->bindParam(":id", $id);
$statementIdSelect->bindParam(":id", $id);

$statementId->execute();
$statementIdSelect->execute();

$resId = $statementIdSelect->fetchAll();

if (sizeof($resId) === 0) {
    
    echo "Le Qcm numéro " . $id . " à bien été supprimé \n";
    
    Header('Location: qcmViews.php');
    
}Else{
    
    Header('Location: Erreur.php');
    
}

// Header('Location: qcmViews.php');

?>