<?php
session_start();

//        require '_conf.php';
require '_conf.php';
include 'includes/header.php';
//include 'fichier.php';
//var_dump($_POST);



$invitation = filter_input(INPUT_POST, 'id');

$strid=$helper->getQCMIdByInvitation($invitation);
//var_dump($strid);

$id= intval($strid['ID_QCM']);
//var_dump($id);
$questions = $helper->getQuestionsByByQcmId($id);
$nbquestions = array_key_last ($questions);
$nbquestions++;
shuffle ($questions);

$questionsSerialized = json_encode($questions);
//var_dump($questionsSerialized);

//$reponses = $helper->getReponsesByQuestionId($questions[$indice_question]['ID_Question']);

$reponses = [];

foreach ($questions as $question) {
    $reponsesCurrentQuestion = $helper->getReponsesByQuestionId($question['ID_Question']);
    foreach ($reponsesCurrentQuestion as $reponse) {
        $reponses[$question["ID_Question"]][] = $reponse;
    }
}

$reponsesSerialized = json_encode($reponses);



//var_dump($questions);
// end($questions);
//$lastid = key($questions);

//var_dump($lastid);
//if($indice_question == $lastid + 1){
//
//    exit;
//
//}

//$image_question = $questions[$indice_question]["Fichier_Externe_Question"];

//
//var_dump($questions);
//exit;

?>

    <div style="text-align:center;">
        <!--        <input type="button" id="first" onclick="firstPage()" value="first" />-->
        <!--        <input type="button" id="previous" onclick="previousPage()" value="previous"/>-->


        <!--        <input type="button" id="last" onclick="lastPage()" value="last" />-->
        <div id="flash-msg" class="alert" style="display: none"></div>
        <div id="list"></div>
        
    </div>


    <div>Timer: <span id="timerQ"></span></div>
<!--    <div>Timer<span id="timer"></span></div>-->
    
    
    
    
    <script>
        let cptquestion = 1;
        let questions = <?= $questionsSerialized ?>;
        let reponses = <?= $reponsesSerialized ?>;
        let reponsesCompleted = {};
        let currentQuestionIndex = 0;
        let thisQuestionTimer = 0;
        let idqcm = <?=$id?>;
        let nbQ = <?= $nbquestions ?>;
        let tabTimer={};
        
        console.log(questions);
        const dateDebut = new Date();

        function getTimer() {
            return ((new Date() - dateDebut) / 1000).toFixed(0);
        }

        const questionsTimer = [];

      //  let debugTimer = 5;
        $.each(questions, function (key, question) {
         questionsTimer[key] = parseInt(question.Temps);
      //     questionsTimer[key] = debugTimer;
        });

        const cumulatedTimerArray = {};
        Object.freeze(cumulatedTimerArray);

        let cumulatedTimer = 0;
        $.each(questionsTimer, function (key, questionTimer) {
            if (questionsTimer[key - 1] !== undefined) {
                cumulatedTimer = cumulatedTimerArray[key - 1] + questionTimer;
                cumulatedTimerArray[key] = cumulatedTimer;

            } else {
                //first iteration
                cumulatedTimerArray[key] = questionTimer;
            }

        });

        setInterval(
            function () {

                if (getTimer() >= cumulatedTimerArray[cptquestion - 1]) {
                    nextPage();
                }
                $("#timer").html(getTimer());
                thisQuestionTimer++;
                $("#timerQ").html(thisQuestionTimer+'/'+questions[cptquestion - 1]['Temps']);
                if (questions[cptquestion - 1] !== undefined){
                    if (thisQuestionTimer >= questions[cptquestion - 1]['Temps']) {
                        nextPage();
                    }
                }
            },
            1000);

        function loadList() {

            $("#list").html("");

            let currentQuestion = questions[currentQuestionIndex];

            if (currentQuestion !== undefined) {
                currentQuestionId = currentQuestion.ID_Question;
                let reponsesQuestion = reponses[currentQuestionId];
                $("#list").append('<p class="ennonce">Question ' + cptquestion + ': ' + currentQuestion.Ennonce_Question + ' </p>');
                if (currentQuestion.Fichier_Externe_Question !== null) {
                
                    $("#list").append('<div><img width="100" height="100" src="'+ currentQuestion.Fichier_Externe_Question +'"/></div>');
    
                }
                $.each(reponsesQuestion, function (key, reponse) {

                    // console.log(reponse);

                    $("#list").append(reponse.Choix_Reponse);
                    $("#list").append('<input class="reponses" data="' + reponse.ID_Reponse + '" type="checkbox">');
                    $("#list").append('<br>');

                });
                
                $("#list").append('<input type="button" id="next" onclick="nextPage()" value="next"/>');

            } else {

                $("#list").append('<button id="submit" type="submit">' +
                    'Envoyer</button>');

                //hors plage
            }

        }

        function nextPage() {

            //save reponse
            save();
            tabTimer[currentQuestionId]=thisQuestionTimer;
            currentQuestionIndex += 1;
            cptquestion++;
            thisQuestionTimer = 0;
            loadList();
        }

        function previousPage() {

            //save reponse
            save();
            currentQuestionIndex -= 1;
            cptquestion--;
            loadList();
        }

        function save() {

            let reponsesToAdd = $("#list .reponses");

            if (reponsesCompleted[currentQuestionId] === undefined) {
                reponsesCompleted[currentQuestionId] = [];
            }

            reponsesCompleted[currentQuestionId] = {};

            $.each(reponsesToAdd, function (key, reponse) {

                if ($(reponse).is(":checked")) {
                    reponsesCompleted[currentQuestionId][$(reponse).attr("data")] = 1;
                }
                else {
                    reponsesCompleted[currentQuestionId][$(reponse).attr("data")] = 0;
                }
            });
        }


        loadList();

        $("#list").on("click", '#submit', function () {
            console.log("submit");
            console.log(reponsesCompleted);
            
            
            let tabAJAX = {Reponses: reponsesCompleted, idqcm: idqcm, QTimers: tabTimer};
            $.ajax({
                method: "POST",
                url: "traitementPlay.php",
                data: tabAJAX,
                dataType: 'json'
                // success: function(resultat) {
                // console.log(resultat);
                // }
            }).done(function (data) {
                console.log("done");
                console.log(data);
                
                               //refresh classes
                $("#flash-msg").removeClass("alert-success");
                $("#flash-msg").removeClass("alert-danger");

                if(data.statut === "ok") {
                    
                    $("#flash-msg").html('Votre resultat est '+data.score +'/'+nbQ+' et a correctement été enregistré');
                    $("#flash-msg").addClass("alert-success");

                } else if(data.statut === "nok") {
                    $("#flash-msg").html("ERROR");
                    $("#flash-msg").addClass("alert alert-danger");
                }

                $("#flash-msg").show();

//                setTimeout(
//                    function () {
//                        $("#flash-msg").fadeOut('slow'),1500);
//                    },
//                   
//                );
//                
                //listen (ok/nok)
            });
        });


    </script>


<?php include 'includes/footer.php';