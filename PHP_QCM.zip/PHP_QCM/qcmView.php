<?php
session_start();
require '_conf.php';
include 'includes/header.php';

//include 'fichier.php';
if($_SESSION['role']!='Admin' && $_SESSION['role']!='Prof'){
    header('Location: qcmViews.php');
    exit;
}

$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);

if(is_null($id)){
    echo 'This page is invalid';
    exit;
}
    

$qcm = $helper->getQcmById($id);
$questions = $helper->getQuestionsByByQcmId($id);

?>
<div id="containeur_view">
    <div class="view_qcm">
        <div>Qcm Id <?= $qcm["ID_QCM"] ?></div>
        <div>Qcm Titre <?= $qcm["Titre"] ?></div>
        <div>Description : <?= $qcm["Description"] ?></div>
    </div>

    <br/>

    <?php

    foreach ($questions as $key => $question) {
        $image_question = $question["Fichier_Externe_Question"];
        ?>

        <div>

            <div>Question <?= $key + 1 ?></div>
            <div>Ennonce : <?= $question["Ennonce_Question"] ?></div>
            <div>Temps : <?= $question["Temps"] ?></div>
            <?php if ($image_question !== NULL){ ?>
                <div>Image : <img width="100" height="100" src="<?= $image_question ?>"/></div>
            <?php } ?>

            <?php $reponses = $helper->getReponsesByQuestionId($question["ID_Question"]) ?>

            <?php

            foreach ($reponses as $keyrep => $reponse) {
            ?>
                <div>Reponse <?= $keyrep + 1 ?> </div>
                <div><?= $reponse['Choix_Reponse'] ?></div>



            <?php } ?>




        </div>

        <?php
    }

?>
</div>


<?php include 'includes/footer.php';