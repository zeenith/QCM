<?php
session_start();
require '_conf.php';
include 'includes/header.php';

//include 'fichier.php';

if($_SESSION['role']!='Admin'){
    echo "erreur";
    exit;
}

if(is_null($_SESSION)){
    echo 'This page is invalid';
    exit;
}

$limit = isset($_POST["limit-records"]) ? $_POST["limit-records"] : 10;
	$page = null !=(filter_input(INPUT_GET, 'page', FILTER_SANITIZE_NUMBER_INT)) ? filter_input(INPUT_GET, 'page', FILTER_SANITIZE_NUMBER_INT) : 1;
	$start = ($page - 1) * $limit;

if (array_key_exists("search", $_POST)) {
    $keywords = filter_input(INPUT_POST, 'search', FILTER_SANITIZE_STRING);

    $Users = $helper->getUsersByKeywords($keywords);
    
       $result1 = $pdo->query("SELECT username AS username FROM user");
   $custCount = $result1->fetchAll(PDO::FETCH_ASSOC);
   $total = count($custCount);
   	$pages = ceil( $total / $limit );

	$Previous = $page - 1;
	$Next = $page + 1;

} else {
    
   $Users = $helper->getUsersLimit($start,$limit);
   $result1 = $pdo->query("SELECT username AS username FROM user");
   $custCount = $result1->fetchAll(PDO::FETCH_ASSOC);
   $total = count($custCount);
   	$pages = ceil( $total / $limit );

	$Previous = $page - 1;
	$Next = $page + 1;


}


?>
<!-- <a href="index.php">Retour à l'accueil</a> -->






<div class="containeur_qmcs">
    
    <div class="container_pagination">
		
		<div class="row">
			<div class="col-md-10">
				<nav aria-label="Page navigation">
					<ul class="pagination">
				    <li>
                                      <?php if($page != 1){?>
				      <a href="ListUsers.php?page=<?= $Previous; ?>" aria-label="Previous">
				        <span aria-hidden="true">&laquo; Previous</span>
				      </a>
                                      <?php } ?>
				    </li>
				    <?php for($i = 1; $i<= $pages; $i++) : ?>
				    	<li><a href="ListUsers.php?page=<?= $i; ?>"><?= $i; ?></a></li>
                                        <?php $pagemax = $i; ?>
				    <?php endfor; ?>
				    <li>
                                      <?php if($page != $pagemax){?>
				      <a href="ListUsers.php?page=<?= $Next; ?>" aria-label="Next">
				        <span aria-hidden="true">Next &raquo;</span>
                                      <?php } ?>
				      </a>
				    </li>
				  </ul>
				</nav>
			</div>
			<div class="text-center"  >
                            <form class="form2" method="post" action="ListUsers.php">
						<select name="limit-records" id="limit-records">
							<option disabled="disabled" selected="selected">---Limit Records---</option>
							<?php foreach([10,100,500,1000,5000] as $limit): ?>
								<option <?php if( isset($_POST["limit-records"]) && $_POST["limit-records"] == $limit) echo "selected" ?> value="<?= $limit; ?>"><?= $limit; ?></option>
							<?php endforeach; ?>
						</select>
					</form>
				</div>
                </div>
</div>
  
     <form method="post" action="ListUsers.php">

            <div class="container_search">
                <div class="row">
                    <div class="search-bar">
                        <input name="search" class="search-bar" type="text" placeholder="Search" aria-label="Search">
                    </div>
                    <div class="btnsearch">
                        <button class="btnsearch" type="submit">Ok</button>
                    </div>
                </div>
            </div>

     </form>   
  
   


    <?php


//$Users = $helper->AdmingetUsers();


    foreach ($Users as $User) {
        $iduser= $User["id_user"];
        $username = $User["username"];
        $role = $User["Id_role"];
        ?>
    <div id="flex_qcms">
        <div id="flex_voir"><a href="profile.php?id=<?= $iduser ;?>"><button id="bouton_voirqcm">Voir profil <?= $iduser ;?> username : <?= $username ?></button>  </a>

            
        </div>

        <div id="flex_edit">        <a href="createUser.php?id=<?= $iduser ;?>"><button id="bouton_modifier">Modifier</button></a>  
        <button id="bouton_supprimer" onclick="Confirmerdelete(<?= $iduser; ?>)">X</button></div>

    </div>
        <?php
    }
    ?>

</div> 

<script type="text/javascript">
	$(document).ready(function(){
		$("#limit-records").change(function(){
			$('.form2').submit();
		});
	});
</script>


<script>
function Confirmerdelete(id)
{
if (confirm("Confirmez vous vouloir supprimer ce qcm ?"))
{
 document.location.href="./deleteUser.php?id="+id; 
}
}

</script>


    
<?php include 'includes/footer.php'; ?>