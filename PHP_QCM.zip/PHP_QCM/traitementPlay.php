<?php
session_start();
require '_conf.php';

//var_dump($_POST); exit;

$score_total = 0;
$idqcm=filter_input(INPUT_POST, 'idqcm', FILTER_SANITIZE_NUMBER_INT);
$tabreponses =filter_input(INPUT_POST, 'Reponses', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY);
$Timers =filter_input(INPUT_POST, 'QTimers', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY);

$SerialisedTimers = json_encode($Timers);
//var_dump($SerialisedTimers);exit;
//var_dump($tabreponses);
$nbquestions = count($tabreponses);
$iduser = $_SESSION['userId'];

$resScoreUser = ($helper->getScoreUser($iduser, $idqcm));


foreach($tabreponses as $key => $idquestion){
    $score_question_local=0;
    $nbreponses = count($idquestion);
//   var_dump($nbreponses);
    foreach($idquestion as $keyrep => $reponse_user){
        $reponse = $helper->getReponsesId($keyrep);
//      var_dump($reponse);
        $reponsebool = $reponse['is_valid'];
        
        if($reponse_user == $reponsebool){
//        echo 'bonne réponse   ';
          $score_question_local++;
        }
        else{

//           echo'mauvaise réponse    ';
            if($score_question_local >= 1 ){
                $score_question_local--;
            }
        }
    }
    if($score_question_local == $nbreponses){
//        echo 'bravo question validé   ';
        $score_total++;
    }
}
//var_dump($score_total);

//echo "<br> Votre résultat est : $score_total / $nbreponses";

$tabresultat = ['score'=>$score_total];
$tabresultat['statut'] = 'nok';

if(sizeof($resScoreUser) === 0){
    
    $nbessai = 1;
    $statement = $pdo->prepare("INSERT INTO User_Scores (ID_user, ID_QCM, resultat, nb_essais, timers) VALUES (:ID_user, :ID_QCM, :resultat, :nb_essais, :Timers)");
    $statement->bindParam(":ID_user", $iduser, PDO::PARAM_INT );
    $statement->bindParam(":ID_QCM", $idqcm, PDO::PARAM_INT );
    $statement->bindParam(":resultat", $score_total , PDO::PARAM_INT );
    $statement->bindParam(":nb_essais", $nbessai , PDO::PARAM_INT);
    $statement->bindParam(":Timers", $SerialisedTimers , PDO::PARAM_STR);

    $statement->execute();
    
    $tabresultat['statut'] = 'ok';
    
}


else{
    
    $statement = $pdo->prepare("UPDATE User_Scores SET resultat = :resultat, timers = :Timers Where ID_user= :ID_user AND ID_QCM = :ID_QCM");
    $statement->bindParam(":ID_user", $iduser, PDO::PARAM_INT );
    $statement->bindParam(":ID_QCM", $idqcm, PDO::PARAM_INT );
    $statement->bindParam(":resultat", $score_total, PDO::PARAM_INT );
    $statement->bindParam(":Timers", $SerialisedTimers , PDO::PARAM_STR);
    
    $statement->execute();
    
    $query = "SELECT nb_essais FROM User_Scores Where ID_user= :ID_user AND ID_QCM = :ID_QCM";
    $statement2 = $pdo->prepare($query);
    $statement2->bindParam(":ID_user", $iduser, PDO::PARAM_INT );
    $statement2->bindParam(":ID_QCM", $idqcm, PDO::PARAM_INT );
    $statement2->execute();
    $nbessaies = $statement2->fetch(PDO::FETCH_ASSOC);
    
//    var_dump($nbessaies);

    $new_nbessaie = intval($nbessaies['nb_essais']);
    $new_nbessaie++;

    $statement3 = $pdo->prepare("UPDATE User_Scores SET nb_essais = :updatednbessai Where ID_user= :ID_user AND ID_QCM = :ID_QCM");
    $statement3->bindParam(":updatednbessai", $new_nbessaie, PDO::PARAM_INT );
    $statement3->bindParam(":ID_user", $iduser, PDO::PARAM_INT );
    $statement3->bindParam(":ID_QCM", $idqcm, PDO::PARAM_INT );

    $statement3->execute();
    
    $tabresultat['statut'] = 'ok';
}



echo json_encode($tabresultat);