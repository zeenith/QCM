<?php
session_start();
session_destroy();
$_SESSION = [];
Header('Location: index.php');
