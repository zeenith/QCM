<?php
session_start();
require '_conf.php';
//var_dump($_POST);exit;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



$id_qcm = filter_input(INPUT_POST, 'ID_QCM', FILTER_SANITIZE_NUMBER_INT);
$titre_qcm = filter_input(INPUT_POST, 'Titre_QCM', FILTER_SANITIZE_STRING);
$description_qcm = filter_input(INPUT_POST, 'Description_QCM', FILTER_SANITIZE_STRING);
$questions = filter_input(INPUT_POST, 'questions', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY);
//$questions = $_POST['questions'];
//$questions = filter_input_array(INPUT_POST, 'questions');
//var_dump($_POST['questions']['1']['temps']);
//var_dump($_POST);
//var_dump($_POST['questions']['1']['reponses']);
//var_dump($_FILES);

foreach($_POST['questions'] as $key => $question ){
    

    
    if(!array_key_exists('reponses', $question)){
    
        Header('Location: Erreur.php');
        exit;
    }
    
}


$targetDir = "./images/question/";
$imageArray = [];

$randomstring = $helper->genererChaineAleatoire();

$imageNumber = 1;

foreach ($_FILES as $file) {

    foreach ($file["name"] as $key => $image) {

        $basename = $image["img_question"];

        $targetFile = $targetDir . $randomstring . $basename;

        if (move_uploaded_file($file["tmp_name"][$key]["img_question"], $targetFile)) {

            $imageArray[$imageNumber] = $targetFile;
            
        }

        $imageNumber++;
    }

}

if($titre_qcm == ""){echo "titre pas modifié  \n";}

else{
    $statement = $pdo->prepare("UPDATE QCM SET  Titre = :titre WHERE ID_QCM = :id_qcm ");
    $statement->bindParam(":titre", $titre_qcm);
 
    $statement->bindParam(":id_qcm", $id_qcm);

    $statement->execute();
    
    echo "ok titre modifié \n";
}

if($titre_qcm == ""){echo "description pas modifié  \n";}
else{
    $statement = $pdo->prepare("UPDATE QCM SET  Titre = :titre, Description = :description WHERE ID_QCM = :id_qcm ");
    $statement->bindParam(":titre", $titre_qcm);
    $statement->bindParam(":description", $description_qcm);
    $statement->bindParam(":id_qcm", $id_qcm);

    $statement->execute();
    
    echo "ok description modifié \n";
}





//    $targetDir = "./images/question";

  foreach ($questions as $key => $question) {

    if(!array_key_exists('id_question', $question)){
        
        $statement = $pdo->prepare("INSERT INTO Question (Ennonce_Question, Fichier_Externe_Question, Temps, ID_QCM) VALUES (:ennonce,:image_path, :temps, :id_qcm)");

        $statement->bindParam(":ennonce", $question["ennonce"]);
        $statement->bindParam(":temps", $question["temps"]);
        $statement->bindParam(":image_path", $imageArray[$key]);
        $statement->bindParam(":id_qcm", $id_qcm);

        $statement->execute();

    //        $targetFile = $targetDir . basename($_FILES[$key]["name"]);
    //        move_uploaded_file($_FILES[$key]["tmp_name"], $targetFile);

        echo "Question " . $key . " créee \n";

        $idQuestion = $pdo->lastInsertId();

        foreach ($question["reponses"] as $reponse) {

            //if we have its a valid reponse
            $isValid = false;
            if (array_key_exists("is-valid", $reponse)) {
                $isValid = true;
            }

            $statement = $pdo->prepare("INSERT INTO Reponse (Choix_Reponse, is_valid, id_question) VALUES (:choix_reponse, :is_valid, :id_question)");

            $statement->bindParam(":choix_reponse", $reponse["text"]);
            $statement->bindParam(":is_valid", $isValid, PDO::PARAM_BOOL);
            $statement->bindParam(":id_question", $idQuestion);

            $statement->execute();

        }  
        
        
    }
      
      
    else{  
        var_dump($question['id_question']);
        $tmpIdQ = $helper->getQuestionById($question['id_question']);
        var_dump($tmpIdQ);
        
        if($question["ennonce"] == ""){echo "énnoncé pas modifié  \n";}
        else{
            $statement2 = $pdo->prepare("UPDATE Question SET Ennonce_Question = :ennonce Where ID_Question = :Id_question");       
            $statement2->bindParam(":ennonce", $question["ennonce"]);


            $statement2->bindParam(":Id_question", $question['id_question']);

            $statement2->execute();
            
            echo "Ennoncé Question ". $key . " modifiée \n";
        }
        
        if($question["temps"] == ""){echo "temps pas modifié  \n";}
        else{
            $statement2 = $pdo->prepare("UPDATE Question SET Temps = :temps  Where ID_Question = :Id_question");       

            $statement2->bindParam(":temps", $question["temps"]);

            $statement2->bindParam(":Id_question", $question['id_question']);

            $statement2->execute();
            
        }
        if(array_key_exists($key, $imageArray)){
            $statementimg = $pdo->prepare("UPDATE Question SET Fichier_Externe_Question = :image_path Where ID_Question = :Id_question ");
            $statementimg->bindParam(":image_path", $imageArray[$key]);
            $statementimg->bindParam(":Id_question", $question['id_question']);

            $statementimg->execute();
        }

    //    $targetFile = $targetDir . basename($_FILES[$key]["name"]);
    //    move_uploaded_file($_FILES[$key]["tmp_name"], $targetFile);



        foreach ($question["reponses"] as $keyrep => $reponse) {

            if($reponse["text"] == ""){echo "réponse text pas modifié  \n";}
            else {
            $statement3 = $pdo->prepare("UPDATE Reponse SET Choix_Reponse = :choix_reponse Where ID_Reponse = :id_reponse");


            $statement3->bindParam(":id_reponse", $keyrep);
            $statement3->bindParam(":choix_reponse", $reponse["text"]);


            $statement3->execute();
            }
            
        $isValid = false;
        if (array_key_exists("is-valid", $reponse)) {
            $isValid = true;
        }
        $statement = $pdo->prepare("UPDATE Reponse SET is_valid = :is_valid Where ID_Reponse = :id_reponse");
        
        $statement->bindParam(":id_reponse", $keyrep);
        $statement->bindParam(":is_valid", $isValid, PDO::PARAM_BOOL);    
        
        $statement->execute();
            
        }
    
    }
  }
  
  Header('Location: createQcm.php?id='.$id_qcm);
  
