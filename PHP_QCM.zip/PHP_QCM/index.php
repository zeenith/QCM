<?php
session_start();
require '_conf.php';
include 'includes/header.php';

        //include 'fichier.php';
?>
<div class="animation-area">
  <ul class="box-area">
         <li></li>
         <li></li>
           <li></li>
           <li></li>
           <li></li>
            <li></li>
        </ul>
</div>

<?php
    if(empty($_SESSION)){?>
    <div id="container_menu">
        <div><a href="createUser.php"><button class="bouton_menu">Account</button></a></div>
    </div>
    <?php } ?>


     <?php if($_SESSION['role']==='Admin' || $_SESSION['role']==='Prof'){?>
    <div id="container_menu">
        <div>
            <div><a href="createQcm.php"><button class="bouton_menu">Créer</button></a></div>
            <div><a href="qcmViews.php"><button class="bouton_menu">Edit</button></a></div>
           
                
                
            <div><a href="createUser.php"><button class="bouton_menu">Account</button></a></div>
                    
            
            <div><a href="MesResultats.php"><button class="bouton_menu">Résultat</button></a></div>
            <div><a href="ListUsers.php"><button class="bouton_menu">Users</button></a></div>
  
        </div>
    </div>
    <?php } ?>
    
    <?php if($_SESSION['role']==='Eleve'){?>
    <div id="container_menu">
        <div>

            <div><a href="qcmViews.php"><button class="bouton_menu">JOUER</button></a></div>

                    
            
            <div><a href="MesResultats.php"><button class="bouton_menu">Résultat</button></a></div>

  
        </div>
    </div>
    <?php } ?>




<?php include 'includes/footer.php'; ?>