<?php
session_start();
require '_conf.php';

//var_dump($_FILES);exit;
//var_dump($_POST);
//exit;








$titre_qcm = filter_input(INPUT_POST, 'Titre_QCM', FILTER_SANITIZE_STRING);
$description_qcm = filter_input(INPUT_POST, 'Description_QCM', FILTER_SANITIZE_STRING);
$questions = filter_input(INPUT_POST, 'questions', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY);

var_dump($_POST);

//var_dump($_POST['questions']); exit;

//var_dump($questions); exit;

if($titre_qcm == ""){
    
    Header('Location: Erreur.php');
    exit;
    
}

if(is_null($questions)){
    
    Header('Location: Erreur.php');
    exit;
}


foreach($questions as $key => $question ){
    
    if($question['ennonce'] == ""){
    
        Header('Location: Erreur.php');
        exit;
    }
    
    if(!array_key_exists('reponses', $question)){
    
        Header('Location: Erreur.php');
        exit;
    }
    
}


$titreQuery = 'SELECT * FROM QCM WHERE Titre = :titre_qcm';
$descriptionQuery = 'SELECT * FROM QCM WHERE Description = :description_qcm';

$statementtitre = $pdo->prepare($titreQuery);
$statementtitre->bindParam(":titre_qcm", $titre_qcm);

$statementdescription = $pdo->prepare($descriptionQuery);
$statementdescription->bindParam(":description_qcm", $description_qcm);

$statementtitre->execute();
$statementdescription->execute();


$targetDir = "./images/question/";
$imageArray = [];

//var_dump($_FILES);

$randomstring = $helper->genererChaineAleatoire();

$imageNumber = 1;

foreach ($_FILES as $file) {

    foreach ($file["name"] as $key => $image) {

        $basename = $image["img_question"];

        $targetFile = $targetDir . $randomstring . $basename;

        if (move_uploaded_file($file["tmp_name"][$key]["img_question"], $targetFile)) {

            $imageArray[$imageNumber] = $targetFile;

        }

        $imageNumber++;
    }

}

$invitation = time(). uniqid();

$statement = $pdo->prepare("INSERT INTO QCM (Titre, Description, Invitation) VALUES (:titre, :description, :invitation)");
$statement->bindParam(':titre', $titre_qcm);
$statement->bindParam(':description', $description_qcm);
$statement->bindParam(':invitation', $invitation);

$statement->execute();

echo "ok qcm crée \n";

$idQcm = $pdo->lastInsertId();



//    $targetDir = "./images/question";

foreach ($questions as $key => $question) {

    $statement = $pdo->prepare("INSERT INTO Question (Ennonce_Question, Fichier_Externe_Question, Temps, ID_QCM) VALUES (:ennonce,:image_path, :temps, :id_qcm)");

    $statement->bindParam(":ennonce", $question["ennonce"]);
    $statement->bindParam(":temps", $question["temps"]);
    $statement->bindParam(":image_path", $imageArray[$key]);
    $statement->bindParam(":id_qcm", $idQcm);

    $statement->execute();

//        $targetFile = $targetDir . basename($_FILES[$key]["name"]);
//        move_uploaded_file($_FILES[$key]["tmp_name"], $targetFile);

    echo "Question " . $key . " créee \n";

    $idQuestion = $pdo->lastInsertId();

    foreach ($question["reponses"] as $reponse) {

 
        $isValid = false;
        if (array_key_exists("is-valid", $reponse)) {
            $isValid = true;
        }

        $statement = $pdo->prepare("INSERT INTO Reponse (Choix_Reponse, is_valid, id_question) VALUES (:choix_reponse, :is_valid, :id_question)");

        $statement->bindParam(":choix_reponse", $reponse["text"]);
        $statement->bindParam(":is_valid", $isValid, PDO::PARAM_BOOL);
        $statement->bindParam(":id_question", $idQuestion);

        $statement->execute();

    }


}


//    $qcmquery = "SELECT * "

/*} else {

    echo "nok";

} */
Header('Location: qcmViews.php');