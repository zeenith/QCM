<?php
session_start();
require '_conf.php';

//var_dump($_FILES);
//var_dump($_POST);
//exit;








$user = filter_input(INPUT_POST, 'user', FILTER_SANITIZE_STRING);
$password = filter_input(INPUT_POST, 'password');

$password_hash = password_hash($password, PASSWORD_BCRYPT);


$userQuery = "SELECT * FROM user WHERE username = '$user'";
$statementUser = $pdo->prepare($userQuery);
$statementUser->execute();
$resUsername = $statementUser->fetchAll();

if (sizeof($resUsername) === 0){
    
    $statement = $pdo->prepare("INSERT INTO user (username, password, Id_role) VALUES (:user, :password, 2)");
    $statement->bindParam(":user", $user);
    $statement->bindParam(":password", $password_hash);
    $statement->execute();
    
    echo "ok";
}

else {

    echo "nok";

}


