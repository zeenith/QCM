<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>QCM GENERATOR</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <link rel="stylesheet" href="./includes/style.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">        
    
    </head>
   
    <body>


<?php

require '_conf.php';

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// echo " CEST UNE ERREUR FATALE " ;
?>

                <div class="animation-area_error">
                  <ul class="box-area">
                         <li></li>
                         <li></li>
                           <li></li>
                           <li></li>
                           <li></li>
                            <li></li>
                        </ul>
                </div>
                <div id="error">

                    ERROR

                </div>
        
        
    </body>

</html>