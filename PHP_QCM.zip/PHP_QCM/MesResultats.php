<?php
session_start();
require '_conf.php';
include 'includes/header.php';

//include 'fichier.php';



if(empty($_SESSION)){
    echo 'This page is invalid';
    exit;
}

$monid = $_SESSION['userId'];
$messcores = $helper->resultats($monid);
//var_dump($messcores);
$compteur_indice_resultat = 1;
?>

<div class="container">
    
    
          <?php foreach($messcores as $key => $monscore){ 
                    $qcminfo = $helper->getQcmById($monscore['ID_QCM']);
//                    var_dump($qcminfo);
                    ?>
                    <button class="btn btn-secondary" type="button" data-toggle="collapse" data-target="#contenu<?=$compteur_indice_resultat?>"><?=$qcminfo['Titre']?></button>
                    <div class="collapse" id="<?='contenu'.$compteur_indice_resultat;?>">
                        <?php $timers = json_decode($monscore['timers'], true); 
//                         var_dump($timers);
                        $nbQ=count($timers) ;?>
                        <span>Description: <?=$qcminfo['Description']?></span>
                        <br>
                        <span>Résultat: <?=$monscore['resultat']?>/<?=$nbQ?></span>
                        <br>
                      <?php  
                      if($_SESSION['role']=='Admin' ||$_SESSION['role']=='Prof'){
                        foreach($timers as $key => $timer){?>
                        <span> Temps pour la question id <?=$key?>: <?=$timer?> secondes</span>
                        <br>
                            
                            
                        <?php }
                            
                      }
                        ?>
                       
                        </div>
            <?php        
                         $compteur_indice_resultat++; }?>
<!--                       </div> -->
                        
    
    
    
</div>


<?php    
include 'includes/footer.php'; ?>