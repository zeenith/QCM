<?php
session_start();//Création et acces à la session

//check if user already connected
if(array_key_exists("user", $_SESSION)) {
    Header('Location: index.php');
}

require '_conf.php';
//var_dump($_POST);
$username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
$password = filter_input(INPUT_POST, 'password',FILTER_DEFAULT);


$loginQuery = "SELECT * FROM user JOIN Role ON Role.Id_Role = user.Id_Role Where username  = :username2";

$statement = $pdo->prepare($loginQuery);

$statement->bindParam(":username2", $username);


$statement->execute();

$res = $statement->fetch(PDO::FETCH_ASSOC);
var_dump($res);

if (password_verify($password, $res['password'])) {

    $_SESSION['userId'] = $res['id_user'];
    $_SESSION['user'] = $res['username'];
    $_SESSION['role'] = $res['Nom_role'];
    

Header('Location: index.php');

} else {

    echo "User not found";
    ?>

    <a href="index.php">Retour à l'accueil</a>

    <?php
}


