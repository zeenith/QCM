<?php
session_start();
require '_conf.php';
include 'includes/header.php';

//include 'fichier.php';

$iduser = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);

if(empty($iduser)){
    echo 'This page is invalid';
    exit;
}

if($_SESSION['role'] != 'Admin' && $_SESSION['Prof'] != 'Prof'){
        echo 'This page is invalid';
    exit;
}

//$qcm = $helper->getQcmById($id);
//$questions = $helper->getQuestionsByByQcmId($id);
$scores = $helper->resultats($iduser);

//var_dump($scores);
$compteur_indice_resultat = 1;

$profile = $helper->profile($iduser);
//var_dump($profile);
?>
<div id="containeur_view">
    <div class="view_qcm">
        <div>Nom d'utilisateur : <?= $profile["username"] ?></div>
        <div>Role : <?= $profile["Nom_role"] ?></div>
    </div>

    <br/>





    
    
          <?php foreach($scores as $key => $score){ ;?>

                    <button class="btn btn-secondary" type="button" data-toggle="collapse" data-target="#contenu<?=$compteur_indice_resultat?>">QCM : <?=$score['ID_QCM']?></button>
                    <div class="collapse" id="<?='contenu'.$compteur_indice_resultat;?>">
                        <?php $timers = json_decode($score['timers'], true); 
//                         var_dump($timers);
                        $nbQ=count($timers) ;?>
                        <span>Résultat: <?=$score['resultat']?>/<?=$nbQ?></span>
                        </br>
                      <?php  
                      if($_SESSION['role']=='Admin' || $_SESSION['role']=='Prof'){
                        foreach($timers as $key => $timer){?>
                        <span> Temps pour la question id <?=$key?>: <?=$timer?> secondes</span>
                        </br>
                            
                            
                        <?php }
                            
                      }
                        ?>
                       
                        </div>
            <?php        
                         $compteur_indice_resultat++; }?>
<!--                       </div> -->
                        
    
    
    
</div>



<?php include 'includes/footer.php';