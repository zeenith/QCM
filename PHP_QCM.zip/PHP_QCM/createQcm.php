
<?php
session_start();
require '_conf.php';
include 'includes/header.php';

        //include 'fichier.php';

if($_SESSION['role']=='Eleve'){
    echo "erreur";
    exit;
}

$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
$compteur_question = 1;
$compteur_QuestionReponses=[];
        


$bouton='Créer';

?>



    <div class="animation-area">
  <ul class="box-area">
         <li></li>
         <li></li>
           <li></li>
           <li></li>
           <li></li>
            <li></li>
        </ul>
</div>

<div class="containeur_creat">
    
    
    
       
    <div id="create_transparent">
        
    <?php    if(!is_null($id)){
        $qcm = $helper->getQcmById($id);
        $questions = $helper->getQuestionsByByQcmId($id);
        //var_dump($qcm);
//        var_dump($questions);
        $bouton='Modifier';
        
    ?>    
              
            <form name="myForm2" action="update.php" enctype="multipart/form-data" method="POST" onsubmit="return validateForm()">
            
                <input type="hidden" name="ID_QCM" value="<?=$id;?> ">
                <label for="Titre_QCM"></label>
                <p>
                    <input type="text" name="Titre_QCM" placeholder="saisissez votre nouveau titre" value="<?= $qcm['Titre'];?>">
                </p>
                <div><label for="Description_QCM"></label>
                    <br>
                   <textarea class="description_qcm" name="Description_QCM" placeholder="saisissez votre nouvelle description"><?= $qcm['Description'];?></textarea>
                </div>
        
              
                    
          <?php foreach($questions as $key => $question){ 
              
              
              $image_question = $question["Fichier_Externe_Question"];?>
<!--                <div class="ennoncetemps">-->
                    <button class="btn btn-secondary" type="button" data-toggle="collapse" data-target="#contenu<?=$compteur_question?>">Question <?=$compteur_question?></button>
                    <div class="collapse" id="<?='contenu'.$compteur_question;?>">
                        <?php $compteur_QuestionReponses=1; ?>
<!--                    <p class="text_modif_q">Question <?=$key +1;?> </p>-->
                        <input type="hidden" name="questions[<?=$compteur_question?>][id_question]" value="<?=$question['ID_Question'];?>">
                        <div><input class="input_question" type="text" name="questions[<?=$compteur_question?>][ennonce]"  placeholder="Saisissez votre nouvelle énnoncé" value="<?= $question['Ennonce_Question']?>"> </div>
                        <div><input class="input_question"  type="number"  name="questions[<?=$compteur_question?>][temps]" value="<?= $question['Temps']?>">Temps (secondes)</div>
                        <?php if ($image_question !== NULL){ ?>
                            <div>Image : <img width="100" height="100" src="<?= $image_question ?>"/></div>
                        <?php } ?>
                        <div><input type="file" name="questions[<?=$compteur_question?>][img_question]" class="img_preview"></div>
                        <button data-questionId="<?=$compteur_question;?>" class="add-reponses">Ajouter une reponse</button>
                        
                       
                        
 
                         <?php
                            $reponses = $helper->getReponsesByQuestionId($question['ID_Question']);
                            foreach ($reponses as $keyrep => $reponse) {
                            ?>

                            <div>
                                <p class="text_modif_r"> Réponse <?=$keyrep +1 ;?></p>
                                <input placeholder="saisissez votre nouvelle réponse" value="<?= $reponse['Choix_Reponse'];?>" type="text" name="questions[<?=$compteur_question?>][reponses][<?=$reponse['ID_Reponse'];?>][text]">
                                <?php if($reponse['is_valid']==true){?>
                                <div>  Réponse valide
                                     <input checked type="checkbox" value="false" class="is-valid" name="questions[<?=$compteur_question?>][reponses][<?=$reponse['ID_Reponse'];?>][is-valid]"> </div>
                                <?php } 
                                
                                else {?>
                                <div> Réponse invalide
                                     <input type="checkbox" value="false" class="is-valid" name="questions[<?=$compteur_question?>][reponses][<?=$reponse['ID_Reponse'];?>][is-valid]"> </div>
                                <?php } ?>
                            </div>
                            <?php $compteur_QuestionReponses++;?>

            <?php }       
                         $compteur_question++; ?>
<!--                       </div> -->
                    </div>
                <?php
                
                    }
                ?>  
             
            <div id="questions-container">
            </div>
            <div>
                <button id="add-question">Ajouter une question</button>
            </div>    
                
                
                
                
                <input class="boutton_envoyer" type="submit" value="<?=$bouton?>">
            </form>
        
        <?php } 
        
        
        
        else{
        
        ?>
            
            
            
            
            
            
            
            
       
        
        <form name="myForm" action="traitement.php" enctype="multipart/form-data" method="POST" onsubmit="return validateForm()">
            <p>
                <input type="text" name="Titre_QCM" placeholder="Saisir le titre du QCM" required="">
            </p>
            <div class="cont_desc"><label for="Description_QCM">Saisir la description du QCM:</label>
                <br>
               <textarea name="Description_QCM" ></textarea>
            </div>
<!--            <p><input type="file" name="img_qcm" class="img_preview"></p>-->

            <div id="questions-container">
            </div>
            <div>
                <button id="add-question">Ajouter une question</button>
            </div>


            <input class="boutton_envoyer" type="submit" value="<?=$bouton?>">
        </form>
        
        <?php } ?>
        
    </div>


</div>

   


<script>
    let cptQuestion = <?=$compteur_question?>;
    let cptQuestionReponses = [];

    $("#add-question").on("click", function(e)
    {
        e.preventDefault();
        $("#questions-container").append(
                '<div><button class="btn btn-secondary" type="button" data-toggle="collapse" data-target="#contenu'+cptQuestion+'">Question '+cptQuestion+'</button>'+
                '</div>'+ 
                '<div class="collapse"id="contenu'+cptQuestion+'">' +
                    '<div>' +
                        '<input class="input_question" type="text" name="questions[' + cptQuestion + '][ennonce]" required="">Ennonce </div>' +
                    '<div>' +
                        '<input class="input_question"  type="number" value=120 name="questions[' + cptQuestion + '][temps]">Temps (secondes) </div>' +
                    '<div>' +
                        '<input class="input_question"  type="file" name="questions['+ cptQuestion +'][img_question]" class="img_preview"> </div>' +
                    '<button data-questionId="' + cptQuestion +'" class="add-reponses">Ajouter une reponse</button>' +
                '</div>');

        cptQuestionReponses[cptQuestion] = 1;
        cptQuestion++;
    });

    $('body').on("click",".add-reponses",function(e)
    {
        $(this).parent().append('<div>' +
            '<input required="" type="text" name="questions[' + this.dataset.questionid + '][reponses][' + cptQuestionReponses[this.dataset.questionid] + '][text]">Reponse ' + cptQuestionReponses[this.dataset.questionid] +
            '<input type="checkbox" value="false" class="is-valid" name="questions[' + this.dataset.questionid + '][reponses][' + cptQuestionReponses[this.dataset.questionid] + '][is-valid]"> ' +
            '</div>');
        cptQuestionReponses[this.dataset.questionid]++;
        e.preventDefault();
    });

    $('body').on("change",".is-valid",function(e)
    {
        if($(this).is(":checked"))
        {
            $(this).val("true");
        }
        else {
            $(this).val("false");
        }
    });

    $('body').on("change",".is-valid",function(e)
    {
        if($(this).is(":checked"))
        {
            $(this).val("true");
        }
        else {
            $(this).val("false");
        }
    });



    $(".img_preview").on("change", function () {
        filePreview(this);
    });

    function filePreview(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $("#img-" + input.name).remove();
                $(input).after('<img id="img-' + input.name + '" src="' + e.target.result + '" width="100" height="100" />');
            }
        }
        reader.readAsDataURL(input.files[0]);
    }


function validateForm() {
  var x = document.forms["myForm"]["Titre_QCM"].value;
  if (x == "") {
    alert("Remplir les champs requis svp");
    return false;
  }
} 




</script>

<?php include 'includes/footer.php';

