<?php
session_start();

require '_conf.php';
include 'includes/header.php';


?>

<div class="conteneuruser">
    <div class="userform">
        <div id="flash-msg" class="alert" style="display: none"></div>
        <form id="create_account" method="POST">
        
        
 
        <div class="placeholder">
            <input autocomplete="on" id="userinput" name="user" placeholder="Nom utilisateur" required="" class="form_holder" data-qa-id="input-login" type="text" value="">
        </div>
        <div class="placeholder">
            <input autocomplete="on" id="userinput" name="password" placeholder="Mot de passe" required="" class="form_holder" data-qa-id="input-password" type="password" value="">
        </div>
            
            <div>    <button id="button_compte" name="register">Créer mon compte</button> </div>

        </form>
    </div> 
        
        
    
    
    
    
</div>

<script>

    $(document).ready(function () {
        $("#create_account").on("submit", function (e) {
            e.preventDefault();
            $.ajax({
                method: "POST",
                url: "traitementUser.php",
                data: $(this).serialize()
            }).done(function (data) {

                //refresh classes
                $("#flash-msg").removeClass("alert-success");
                $("#flash-msg").removeClass("alert-danger");

                if(data === "ok") {

                    $("#flash-msg").html("Le compte à été crée avec succès :)");
                    $("#flash-msg").addClass("alert-success");

                } else if(data === "nok") {
                    $("#flash-msg").html("Le Compte n'a pas pu être crée :(");
                    $("#flash-msg").addClass("alert alert-danger");
                }

                $("#flash-msg").show();

                setTimeout(
                    function () {
                        $("#flash-msg").fadeOut(1500);
                    },
                    1500
                );
            });
        })
    });

</script>

<?php include 'includes/footer.php'; ?>