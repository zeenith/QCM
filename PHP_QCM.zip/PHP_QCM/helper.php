<?php

class helper
{

    /**
     * Our etablished PDO
     * @var PDO
     */
    private $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }


    /**
     * @param $id
     * @return mixed
     */
    public function getQcmById($id) {
        $query = "SELECT * FROM QCM WHERE ID_QCM = $id";
        $statement = $this->pdo->query($query);
        $statement->execute();
        return $statement->fetch(PDO::FETCH_ASSOC);
    }
    
    public function getScoreUser($iduser, $idqcm) {
        $query = "SELECT * FROM User_Scores WHERE ID_user = $iduser AND ID_QCM = $idqcm ";
        $statement = $this->pdo->query($query);
        $statement->execute();
        return $statement->fetchall(PDO::FETCH_ASSOC);
    }
    
        public function getQuestionById($id) {
        $query = "SELECT * FROM Question WHERE ID_Question = $id";
        $statement = $this->pdo->query($query);
        $statement->execute();
        return $statement->fetch(PDO::FETCH_ASSOC);
    }

    public function getQuestionsByByQcmId($id) {
        $query = "SELECT * FROM Question WHERE ID_QCM = $id";
        $statement = $this->pdo->query($query);
        $statement->execute();
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getQCMIdByInvitation($invit) {
//        var_dump($invit);
        $query = "SELECT ID_QCM FROM QCM WHERE Invitation = '$invit'";
        $statement = $this->pdo->query($query);
        $statement->execute();
        return $statement->fetch(PDO::FETCH_ASSOC);
    }    

    public function getReponsesByQuestionId($id) {
        $query = "SELECT * FROM Reponse WHERE ID_Question = $id";
        $statement = $this->pdo->query($query);
        $statement->execute();
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getReponsesId($id) {
    $query = "SELECT * FROM Reponse WHERE ID_Reponse = $id";
    $statement = $this->pdo->query($query);
    $statement->execute();
    return $statement->fetch(PDO::FETCH_ASSOC);
    }
    
    public function AdmingetUsers() {
    $query = "SELECT * FROM user";
    $statement = $this->pdo->query($query);
    $statement->execute();
    return $statement->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function ProfgetUsers() {
    $query = "SELECT * FROM user where Id_role = Eleve";
    $statement = $this->pdo->query($query);
    $statement->execute();
    return $statement->fetchAll(PDO::FETCH_ASSOC);
    }
    
    
    public function getQcms()
    {
        $query = "SELECT * FROM QCM";
        $statement = $this->pdo->query($query);
        $statement->execute();
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function deleteQcmsById($id)
    {
        $query = "DELETE FROM QCM WHERE ID_QCM = $id";
        $statement = $this->pdo->query($query);
        $statement->execute();
        
    }
    
        
    function genererChaineAleatoire($longueur = 10)
        {
        $caracteres = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
         $longueurMax = strlen($caracteres);
         $chaineAleatoire = '';
         for ($i = 0; $i < $longueur; $i++)
            {
            $chaineAleatoire .= $caracteres[rand(0, $longueurMax - 1)];
            }
         return $chaineAleatoire;
        }
    
    public function getQcmByKeywords($keywords) 
        {
        $query = "SELECT * FROM QCM where Titre like '%" . $keywords . "%'";
        $statement = $this->pdo->query($query);
        $statement->execute();
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }  
    
    public function getUsersByKeywords($keywords) 
        {
        $query = "SELECT * FROM user where username like '%" . $keywords . "%'";
        $statement = $this->pdo->query($query);
        $statement->execute();
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }  
    
    
        public function getQcmsLimit($start, $limit)
    {
        $query = "SELECT * FROM QCM ORDER BY ID_QCM DESC LIMIT $start, $limit";
        $statement = $this->pdo->query($query);
        $statement->execute();
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }
    
    
            public function getUsersLimit($start, $limit)
    {
        $query = "SELECT * FROM user ORDER BY id_user DESC LIMIT $start, $limit";
        $statement = $this->pdo->query($query);
        $statement->execute();
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }
    
    
        public function resultats($id_user)
    {
        $query = "SELECT * FROM User_Scores WHERE ID_user = $id_user";
        $statement = $this->pdo->query($query);
        $statement->execute();
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }  

    public function profile($id_user)
    {
        $query = "SELECT * FROM user JOIN Role ON Role.Id_Role = user.Id_Role WHERE id_user = $id_user";
        $statement = $this->pdo->query($query);
        $statement->execute();
        return $statement->fetch(PDO::FETCH_ASSOC);
    }  
}



