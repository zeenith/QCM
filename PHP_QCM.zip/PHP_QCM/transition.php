<?php
session_start();
require '_conf.php';
include 'includes/header.php';

//include 'fichier.php';

$invitation = filter_input(INPUT_GET, 'id');

if(is_null($invitation)){
    Header('Location: Erreur.php');
    exit;

}

$cpttime = 0;

$qcmid = $helper->getQCMIdByInvitation($invitation);
//var_dump($qcmid);

$qcminfo = $helper->getQcmById($qcmid['ID_QCM']);
$questions = $helper->getQuestionsByByQcmId($qcmid['ID_QCM']);
//var_dump($qcminfo);
//var_dump($questions);


foreach($questions as $question){
    
    $cpttime = $cpttime + $question['Temps'];
    
    
}

if(array_key_exists("user", $_SESSION)) { ?>

<div class="container">
    
    
    <div><p>Vous êtes invité à jouer au QCM : <?=$qcminfo['Titre']  ;?></p>
        <p>Description: <?=$qcminfo['Description']  ;?></p>
        <p>Nombre de questions: <?=sizeof($questions);?></p>
        <p>Vous disposerez de <?=$cpttime?> secondes pour le réaliser</p>
        <p>Bonne chance !</p>
        
    </div>
    
    <form id="transition_form" method="POST" action="play.php">
        
        <input name='id' value="<?=$invitation?>" type="hidden">
        <button type="submit">Je suis prêt</button> 

    </form>
</div>    


<?php
} 


else{ 

    echo "connectez vous";
}


    
include 'includes/footer.php';